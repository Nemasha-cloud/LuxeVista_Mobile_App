package com.example.myapplication;

public class Payment {
    public String servicePrice;
    public String serviceName;
    public String cardHolderName;
    public String cardNumber;
}
