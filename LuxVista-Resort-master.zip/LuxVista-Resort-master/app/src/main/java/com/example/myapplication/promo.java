package com.example.myapplication;

public class promo {
    public String name;
}
