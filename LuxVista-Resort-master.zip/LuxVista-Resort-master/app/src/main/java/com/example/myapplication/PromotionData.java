package com.example.myapplication;

public class PromotionData {
    public String name;

    public PromotionData(String name) {
        this.name = name;

    }
}